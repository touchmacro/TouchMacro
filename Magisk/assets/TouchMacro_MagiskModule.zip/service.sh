#!/system/bin/sh
until [ "$(getprop sys.boot_completed)" ]
do
	sleep 2
done

while :
do
    /system/bin/inputd --service
    sleep 3
done






